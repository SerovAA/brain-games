#!/usr/bin/env python3
from brain_games.calc import calculator_game

def main():
    calculator_game()


if __name__ == '__main__':
    main()