#!/usr/bin/env python3
from brain_games.even import run_brain_even


def main():
    run_brain_even()


if __name__ == '__main__':
    main()
